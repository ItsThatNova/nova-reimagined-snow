package com.itsthatnova.compsnow.texture;

import com.itsthatnova.compsnow.config.SnowVariantConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;

/**
 * Resolves active resource-pack snow textures into a fixed 4-slot set.
 */
public final class SnowVariantResolver {
    private static final Logger LOGGER = LoggerFactory.getLogger("compsnow.variants");
    public static final class_2960 VANILLA_SNOW_ID = class_2960.method_60656("textures/block/snow.png");

    public ResolvedSnowVariantSet resolve(class_3300 resourceManager, SnowVariantConfig config) throws IOException {
        List<ResolvedSnowVariantSet.Slot> slots = new ArrayList<>(SnowVariantConfig.VARIANT_SLOTS);

        class_1011 vanillaImage = loadImage(resourceManager, VANILLA_SNOW_ID);
        if (vanillaImage == null) {
            throw new IOException("Unable to resolve vanilla fallback texture " + VANILLA_SNOW_ID);
        }

        List<String> manualVariants = config.getManualVariants();
        for (int i = 0; i < SnowVariantConfig.VARIANT_SLOTS; i++) {
            if (config.getMode() == SnowVariantConfig.Mode.MANUAL_OVERRIDE) {
                String raw = i < manualVariants.size() ? manualVariants.get(i) : "";
                if (raw != null && !raw.isBlank()) {
                    class_2960 id = class_2960.method_12829(raw.trim());
                    if (id == null) {
                        LOGGER.warn("Snow variant manual slot {} is not a valid identifier: {}", i, raw);
                    } else {
                        class_1011 image = loadImage(resourceManager, id);
                        if (image != null) {
                            slots.add(new ResolvedSnowVariantSet.Slot(image, id, ResolvedSnowVariantSet.SourceType.MANUAL));
                            LOGGER.warn("Snow variant manual slot {} resolved to {}", i, id);
                            continue;
                        }

                        LOGGER.warn("Snow variant manual slot {} could not resolve {}", i, id);
                    }
                }
            }

            slots.add(new ResolvedSnowVariantSet.Slot(copyImage(vanillaImage), VANILLA_SNOW_ID,
                    ResolvedSnowVariantSet.SourceType.VANILLA_FALLBACK));
        }

        LOGGER.warn("Resolved snow variants: [{}, {}, {}, {}]",
                describeSlot(slots.get(0)),
                describeSlot(slots.get(1)),
                describeSlot(slots.get(2)),
                describeSlot(slots.get(3)));

        vanillaImage.close();
        return new ResolvedSnowVariantSet(List.copyOf(slots));
    }

    private String describeSlot(ResolvedSnowVariantSet.Slot slot) {
        return slot.sourceType() + ":" + slot.sourceId();
    }

    private class_1011 loadImage(class_3300 resourceManager, class_2960 id) {
        try {
            Optional<class_3298> resource = resourceManager.method_14486(id);
            if (resource.isEmpty()) {
                return null;
            }

            try (InputStream inputStream = resource.get().method_14482()) {
                return class_1011.method_4309(inputStream);
            }
        } catch (IOException e) {
            LOGGER.warn("Failed reading snow variant texture {}: {}", id, e.getMessage());
            return null;
        }
    }

    private class_1011 copyImage(class_1011 source) {
        class_1011 copy = new class_1011(source.method_4318(), source.method_4307(), source.method_4323(), false);
        copy.method_4317(source);
        return copy;
    }
}
