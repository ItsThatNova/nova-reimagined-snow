package com.itsthatnova.compsnow.texture;

import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_2960;

/**
 * Final resolved 4-slot snow texture set published to Iris.
 */
public record ResolvedSnowVariantSet(List<Slot> slots) {
    public record Slot(class_1011 image, class_2960 sourceId, SourceType sourceType) {}

    public enum SourceType {
        MANUAL,
        VANILLA_FALLBACK
    }
}
