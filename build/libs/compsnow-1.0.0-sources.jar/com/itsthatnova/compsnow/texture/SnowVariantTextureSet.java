package com.itsthatnova.compsnow.texture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Publishes 4 resolved snow textures for shader sampling.
 */
public final class SnowVariantTextureSet {
    private static final Logger LOGGER = LoggerFactory.getLogger("compsnow.variants");

    public static final class_2960 VARIANT_0_ID = class_2960.method_60655("compsnow", "snow_variant_0");
    public static final class_2960 VARIANT_1_ID = class_2960.method_60655("compsnow", "snow_variant_1");
    public static final class_2960 VARIANT_2_ID = class_2960.method_60655("compsnow", "snow_variant_2");
    public static final class_2960 VARIANT_3_ID = class_2960.method_60655("compsnow", "snow_variant_3");

    private static final List<class_2960> IDS = List.of(VARIANT_0_ID, VARIANT_1_ID, VARIANT_2_ID, VARIANT_3_ID);

    private final List<class_1043> textures = new ArrayList<>();

    public void replace(ResolvedSnowVariantSet variantSet, String reason) {
        release();

        class_310 client = class_310.method_1551();
        for (int i = 0; i < IDS.size(); i++) {
            class_1043 texture = new class_1043(variantSet.slots().get(i).image());
            client.method_1531().method_4616(IDS.get(i), texture);
            texture.method_4524();
            textures.add(texture);
        }

        LOGGER.warn("Uploaded {} resolved snow variant textures [{}]", textures.size(), reason);
    }

    public void release() {
        class_310 client = class_310.method_1551();
        for (int i = 0; i < textures.size() && i < IDS.size(); i++) {
            client.method_1531().method_4615(IDS.get(i));
            textures.get(i).close();
        }
        textures.clear();
    }
}
