package com.itsthatnova.compsnow.texture;

import com.itsthatnova.compsnow.events.SnowBiomeManager;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Rebuilds resolved snow textures whenever the active resource pack stack reloads.
 */
public final class SnowVariantReloadListener implements SimpleSynchronousResourceReloadListener {
    private static final Logger LOGGER = LoggerFactory.getLogger("compsnow.variants");
    private static final class_2960 ID = class_2960.method_60655("compsnow", "snow_variant_reload_listener");

    @Override
    public class_2960 getFabricId() {
        return ID;
    }

    @Override
    public void method_14491(class_3300 manager) {
        LOGGER.warn("Resource reload detected — rebuilding resolved snow variants");
        SnowBiomeManager.INSTANCE.refreshSnowVariantTextures("resource reload", manager);
    }
}
