package com.itsthatnova.compsnow;

import com.itsthatnova.compsnow.events.SnowBiomeManager;
import com.itsthatnova.compsnow.texture.SnowVariantReloadListener;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_638;
import net.minecraft.class_642;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client-side entrypoint for Nova Reimagined Snow.
 */
@Environment(EnvType.CLIENT)
public class CompSnowClient implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("compsnow");
    public static final String BUILD_MARKER = "snow-variant-resolver-2026-03-27";

    private class_638 lastWorld = null;

    @Override
    public void onInitializeClient() {
        LOGGER.warn("Nova Reimagined Snow initialising [{}]", BUILD_MARKER);

        SnowBiomeManager.INSTANCE.initializeSnowVariantConfig();
        ResourceManagerHelper.get(class_3264.field_14188)
                .registerReloadListener(new SnowVariantReloadListener());
        SnowBiomeManager.INSTANCE.refreshSnowVariantTextures("client init");

        // World join
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) ->
            client.execute(() -> {
                lastWorld = client.field_1687;
                String worldKey = resolveWorldKey(client);
                SnowBiomeManager.INSTANCE.onWorldJoin(client.field_1687, worldKey);
            })
        );

        // World leave / disconnect
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
            client.execute(() -> {
                lastWorld = null;
                SnowBiomeManager.INSTANCE.onWorldLeave();
            })
        );

        // Chunk load
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) ->
            SnowBiomeManager.INSTANCE.onChunkLoad(chunk.method_12004().field_9181, chunk.method_12004().field_9180)
        );

        // Chunk unload — no-op now since cache keeps data valid
        // ClientChunkEvents.CHUNK_UNLOAD kept for future use

        // Per-tick
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null || client.field_1724 == null) return;

            // Detect dimension change
            if (lastWorld != null && lastWorld != client.field_1687) {
                LOGGER.warn("Dimension change detected [{}]", BUILD_MARKER);
                lastWorld = client.field_1687;
                SnowBiomeManager.INSTANCE.onDimensionChange(client.field_1687);
            }

            SnowBiomeManager.INSTANCE.onClientTick(client);
        });

        LOGGER.warn("Nova Reimagined Snow ready [{}]", BUILD_MARKER);
    }

    /**
     * Resolves a unique world key for cache file naming.
     * Singleplayer: levelName_seed
     * Multiplayer:  serverAddress
     */
    private String resolveWorldKey(class_310 client) {
        // Multiplayer
        class_642 serverInfo = client.method_1558();
        if (serverInfo != null) {
            return "server_" + serverInfo.field_3761;
        }

        // Singleplayer — get level name and seed
        try {
            if (client.method_1576() != null) {
                long seed = client.method_1576().method_30002().method_8412();
                String levelName = client.method_1576().method_27728().method_150();
                return levelName + "_" + seed;
            }
        } catch (Exception e) {
            LOGGER.warn("Could not resolve singleplayer world key: {}", e.getMessage());
        }

        // Fallback
        return "unknown_world";
    }

}
